
import equals.and.hashing.Course;
import equals.and.hashing.Enrollment;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gautam Anand
 */
public class EnrollmentTest {
     private static ArrayList<Enrollment> enrollments;


    public EnrollmentTest() {
    }
    

    @BeforeClass
    public static void setUpClass() {
        Course course1 = new Course(100 ,"Software Development", 500);
        Course course2 = new Course(200 ,"Digital Media", 450);
        Enrollment enrollment1 = new Enrollment(course1,"11/11/21", "S2");
        Enrollment enrollment2 = new Enrollment(course2,"11/11/21", "S2");
        Enrollment enrollment3 = new Enrollment(course1,"12/12/21", "S2");
        Enrollment enrollment4 = new Enrollment(course1,"11/11/21", "S2");
        Enrollment enrollment5 = new Enrollment(course1,"11/11/21", "S2");
        enrollments = new ArrayList<>(Arrays.asList(enrollment1, enrollment2, enrollment3, enrollment4, enrollment5));
        
    }
    
        @AfterClass
    public static void tearDownClass() {
    }
    

    @Before
    public void setUp() {
    }
    

    @After
    public void tearDown() {
    }

    
    
    @Test
    public void testEqualsNull() {
        System.out.println("equals null");
        Object object = null;
        Enrollment instance = enrollments.get(0);
        boolean expResult = false;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }
    

    @Test
    public void testEquals1() {
        System.out.println("Printing equal 1");
        Object object = enrollments.get(1);
        Enrollment instance = enrollments.get(0);
        boolean expResult = false;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }
    

    @Test
    public void testEquals2() {
        System.out.println("Prinitng equal 2");
        Object object = enrollments.get(2);
        Enrollment instance = enrollments.get(0);
        boolean expResult = false;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }
    

    @Test
    public void testEquals3() {
        System.out.println("Printing equal 3");
        Object object = enrollments.get(3);
        Enrollment instance = enrollments.get(0);
        boolean expResult = false;
        boolean result = instance.equals(object);
    }




    @Test
    public void testEqualsSelf() {
        System.out.println("equals self");
        Object object = enrollments.get(0);
        Enrollment instance = enrollments.get(0);
        boolean expResult = true;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }


    @Test
    public void testHashCode() {
        System.out.println("hashCode");
        Enrollment instance = enrollments.get(0);
        int expResult = Objects.hash(instance.course, instance.dateEnrolled, instance.semester);;
        int result = instance.hashCode();
        assertEquals(expResult, result);
    }


    @Test
    public void testToString() {
        System.out.println("toString");
        Enrollment instance = enrollments.get(0);
        String result = instance.toString();
        assertThat(result, containsString(String.valueOf(instance.course)));
        assertThat(result, containsString(instance.dateEnrolled));
        assertThat(result, containsString(instance.semester));
    }
}
