
import equals.and.hashing.Course;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import static org.junit.Assert.*;



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gautam Anand
 */
public class CourseTest {
    private static ArrayList<Course> courses;
    
    public CourseTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {

        Course course1 = new Course(23, "Diploma of Software Development", 1299);
        Course course2 = new Course(22, "Diploma of Software Development", 1299);
        Course course3 = new Course(23, "Diploma of Information Technology", 1299);
        Course course4 = new Course(23, "Diploma of Software Development", 1199);
        courses = new ArrayList<>(Arrays.asList(course1, course2, course3, course4));
    }


    @org.junit.Test
    public void testEqualsNull() {
        System.out.println("Equal is null");        
        Object object = null;
        Course instance = courses.get(0);
        boolean expResult = false;        
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }
    
    @org.junit.Test
    public void testEqualsSelf() {
        System.out.println("Equals Self");        
        Object object = courses.get(0);
        Course instance = courses.get(0);
        boolean expResult = true;        
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }
    
    @org.junit.Test
    public void testEquals1() {
        System.out.println("Course1 == Course1");
        Course course1 = courses.get(0);
        Course course2 = courses.get(1);
        boolean expResult = false;
        boolean result = course1.equals(course2);
        assertEquals(expResult, result);
    }
    
    @org.junit.Test
    public void testEquals2() {
        System.out.println("Course1 == Course2");
        Course course1 = courses.get(0);
        Course course2 = courses.get(2);
        boolean expResult = true;
        boolean result = course1.equals(course2);
        assertEquals(expResult, result);
    }
    
    
    @org.junit.Test
    public void testEquals3() {
        System.out.println("Course1 == Course3");
        Course course1 = courses.get(0);
        Course course2 = courses.get(3);
        boolean expResult = true;
        boolean result = course1.equals(course2);
        assertEquals(expResult, result);
    }


    @org.junit.Test
    public void testHashCode() {
        System.out.println("Printing hashcode ");
        Course instance = courses.get(1);
        int expResult = Objects.hash(instance.courseCode);
        int result = instance.hashCode();
        assertEquals(expResult, result);
    }


    @org.junit.Test
    public void testToString() {
        System.out.println("Printing toString Method");
        Course instance = courses.get(0);
        String result = instance.toString();
        assertThat(result, containsString(String.valueOf(instance.courseCode)));
        assertThat(result, containsString(String.valueOf(instance.courseCost)));
        assertThat(result, containsString(instance.courseName));
    }        
}
