
import equals.and.hashing.Course;
import equals.and.hashing.Student;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import org.junit.BeforeClass;
import org.junit.Test;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gautam Anand
 */
public class StudentTest {
     private static ArrayList<Student> students;
    


    @BeforeClass
    public static void setUpClass() {
        
        Student student1 = new Student(100, "Gautam", "Gautam@mial.com","001128225", "07/11/2021","Software");
        Student student2 = new Student(100, "Dale", "Dale@mial.com","001128225", "07/11/2021","Digital Media");
        Student student3 = new Student(100, "Gautam", "Dale@mial.com","001128225", "07/11/2021","Digital Media");
        Student student4 = new Student(100, "Gautam", "Gautam@mial.com","001128225", "07/11/2021","Digital Media");
        Student student5 = new Student(100, "Gautam", "Gautam@mial.com", "001128225", "02/12/2021","Digital Media");
        Student student6 = new Student(100, "Gautam", "Gautam@mial.com","001128225", "07/11/2021","Digital Media");
        Student student7 = new Student(200, "Dale", "Dale@mial.com","001128226", "02/12/2021","Marketing");
        
        students = new  ArrayList<>(Arrays.asList(student1, student2, student3, student4, student5, student6, student7));
    }
    
 
 

    @Test
    public void testSetEnrollment() {
        System.out.println("setEnrollment");
        Course course = null;
        String dateEnrolled = "";
        String semester = "";
        Student instance = students.get(0);
        instance.setEnrollment(course, dateEnrolled, semester);
    }

 
    @Test
    public void testHashCode() {
        System.out.println("hashCode");
        Student instance = students.get(0);
        int expResult = 97 * 3 + Objects.hashCode(instance.id);
        int result = instance.hashCode();
        assertEquals(expResult, result);
    }


    @Test
    public void testEqualsNull() {
        System.out.println("Equal is Null");
        Object object = null;
        Student instance = students.get(0);
        boolean expResult = false;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }

 
    @Test
    public void testEquals1() {
        System.out.println("student1 == student1");
        Object object = students.get(1);
        Student instance = students.get(0);
        boolean expResult = true;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }


    @Test
    public void testEquals2() {
        System.out.println("student1 == student2");
        Object object = students.get(2);
        Student instance = students.get(0);
        boolean expResult = true;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }


    @Test
    public void testEquals3() {
        System.out.println("student1 == student3");
        Object object = students.get(3);
        Student instance = students.get(0);
        boolean expResult = true;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }


    @Test
    public void testEquals4() {
        System.out.println("student1 == student4");
        Object object = students.get(4);
        Student instance = students.get(0);
        boolean expResult = true;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }


    @Test
    public void testEquals5() {
        System.out.println("student1 == student5");
        Object object = students.get(5);
        Student instance = students.get(0);
        boolean expResult = true;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }


    @Test
    public void testEquals6() {
        System.out.println("student1 == student6");
        Object object = students.get(6);
        Student instance = students.get(0);
        boolean expResult = false;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }


    @Test
    public void testEquals7() {
        System.out.println("student1 == student1");
        Object object = students.get(0);
        Student instance = students.get(0);
        boolean expResult = true;
        boolean result = instance.equals(object);
        assertEquals(expResult, result);
    }

 
    @Test
    public void testToString() {
        System.out.println("Printnig toString Method");
        Student instance = students.get(0);
        String result = instance.toString();
        assertThat(result, containsString(String.valueOf(instance.id)));
        assertThat(result, containsString(instance.name));
        assertThat(result, containsString(instance.email));
        assertThat(result, containsString(String.valueOf(instance.hashCode())));
    }
}
