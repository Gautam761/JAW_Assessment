/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linked.list;

import java.util.Objects;

/**
 *
 * @author Gautam Anand
 */
public class Enrollment {
        public Course course;
    public String dateEnrolled;
    public String semester;

    public Enrollment(Course course, String dateEnrolled, String semester) {
        this.course = course;
        this.dateEnrolled = dateEnrolled;
        this.semester = semester;

    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Enrollment other = (Enrollment) o;
        return course.equals(other.course) && dateEnrolled.equals(other.dateEnrolled) && semester.equals(other.semester);
    }

    @Override
    public int hashCode() {
        return Objects.hash(course, dateEnrolled, semester);
    }

    @Override
    public String toString() {
        return "Enrollment{" +
                "course=" + course +
                ", dateEnrolled='" + dateEnrolled + '\'' +
                ", semester='" + semester + '\'' +
                '}';
    }
}
