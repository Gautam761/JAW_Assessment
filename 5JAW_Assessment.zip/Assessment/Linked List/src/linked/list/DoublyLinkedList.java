/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linked.list;

/**
 *
 * @author Gautam Anand
 */
public class DoublyLinkedList <T>{
     public CustomNode<T> head;

    public CustomNode<T> tail;

    public int count;

    public DoublyLinkedList() {
        head = null;
        tail = null;
        count = 0;
    }


    public void add(T item) {
        CustomNode<T> node = new CustomNode<>(item);
        this.addLast(node);
    }


    private void addFirst(CustomNode<T> node) {

        CustomNode<T> temp = head;
        head = node;
        head.previous = node;
        head.next = temp;
        count++;

        //set head as tail if only element in list
        if (count == 1) {
            tail = head;
        }
    }


    public void addFirst(T item) {
        CustomNode<T> node = new CustomNode<>(item);
        this.addFirst(node);
    }


    public void addLast(CustomNode<T> node) {
        if (count == 0) {
            head = node;
        } else {
            tail.next = node;
        }
        node.previous = tail;
        tail = node;
        count++;
    }

 
    public void addLast(T item) {
        CustomNode<T> node = new CustomNode<>(item);
        this.addLast(node);
    }


    public void removeFrist() {
        if (count != 0) {
            head = head.next;
            head.previous = null;
            count--;
            if (count == 0) {
                tail = null;
            }
        }
    }


    public void removeLast() {

        tail = tail.previous;
        tail.next = null;
        if (count != 0) {
            if (count == 1) {
                head = null;
                tail = null;
            } else {
                tail = tail.previous;
                tail.next = null;
                CustomNode<T> current = head;
                while (current.next != tail) {
                    current = current.next;
                }
                current.next = null;
                tail = current;
            }
            count--;
        }
    }

 
    public boolean remove(T remove) {
        if (count == 0) {
            return false;
        }
        CustomNode<T> current = head;
        CustomNode<T> prev = null;
        while (current != null) {

            if (current.value.equals(remove)) {
                if (prev != null) {
                    prev.next = current.next;
                }

                if (current == tail) {
                    tail = prev;
                }
                if (current == head) {
                    tail = prev;
                }
                count--;
                return true;
            }
            prev = current;
            current = current.next;
        }
        return false;
    }


    public boolean contains(T find) {
        CustomNode<T> current = head;

        while (current != null) {
            if (current.value.equals(find)) {
                return true;
            }
            current = current.next;
        }
        return false;
    }


    @Override
    public String toString() {
        String nodes = "";

        CustomNode<T> current = head;
        while (current != null) {
            nodes += "\n" + current.toString();
            current = current.next;
        }
        return "CustomLinkedList count:" + count + "{" + nodes + "\n}"
                + "\nhead:" + head + ",\ntail:" + tail;

    }
}
