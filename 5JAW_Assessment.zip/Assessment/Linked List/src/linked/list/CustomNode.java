/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linked.list;

/**
 *
 * @author Gautam Anand
 */
public class CustomNode <T>{
    public T value;

    public CustomNode next;

    public CustomNode previous;


    public CustomNode(T value) {
        this.value = value;
        next = null;
        previous = null;
    }

    @Override
    public String toString() {
        return "Node: value:" + value;
    }
}
