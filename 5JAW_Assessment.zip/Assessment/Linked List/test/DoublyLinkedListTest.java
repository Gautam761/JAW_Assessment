
import java.util.ArrayList;
import java.util.Arrays;
import linked.list.DoublyLinkedList;
import linked.list.Student;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gautam Anand
 */
public class DoublyLinkedListTest {
     private static ArrayList<Student> students;
    private static DoublyLinkedList<Student> studentList;
    private static final Student student1 = new Student(100, "Gautam", "Gautam@mial.com","001128225", "07/11/2021","Software");
    private static final Student student2 = new Student(200, "Dale", "Dale@mial.com","001128226", "08/11/2021","Digital Media");
    private static final Student student3 = new Student(300, "Gustavo", "Gustavo@mial.com","001128227", "09/11/2021","IT");
    private static final Student student4 = new Student(400, "Ayaka", "Ayaka@mial.com","001128228", "10/11/2021","Digital Media");
    private static final Student newStudent = new Student(1001, "New Student", "new@mail.com", "0011223344", "19/02/20", "IT");

  
    public DoublyLinkedListTest() {
    }

  
    @BeforeClass
    public static void setUpClass() {
        students = new ArrayList<>(Arrays.asList(student1, student2, student3, student4));

    }

   
    @AfterClass
    public static void tearDownClass() {
    }

   
    @Before
    public void setUp() {
        studentList = new DoublyLinkedList<>();
        studentList.add(student1);
        studentList.add(student2);
        studentList.add(student3);
        studentList.add(student4);
    }

  
    @After
    public void tearDown() {
    }

 
    @Test
    public void testAddFirst() {
        System.out.println("\naddFirst");
        DoublyLinkedList instance = studentList;
        Student add = newStudent;
        System.out.println("\nBefore\n" + studentList);
        int expected = studentList.count + 1;

        instance.addFirst(add);
        System.out.println("\nAfter\n" + studentList);
        int result = studentList.count;
        assertEquals(expected, result);
        assertEquals(add, studentList.head.value);
    }

   
    @Test
    public void testAddLast() {
        System.out.println("\naddLast");
        DoublyLinkedList instance = studentList;
        Student add = newStudent;
        System.out.println("\nBefore\n" + studentList);
        int expected = studentList.count + 1;

        instance.addLast(add);
        System.out.println("\nAfter\n" + studentList);
        int result = studentList.count;
        assertEquals(expected, result);
        assertEquals(add, studentList.tail.value);
    }


    @Test
    public void testRemoveFrist() {
        System.out.println("\nremoveFirst");
        DoublyLinkedList instance = studentList;
        System.out.println("\nBefore\n" + studentList);
        int expected = studentList.count - 1;
        instance.removeFrist();
        System.out.println("\nAfter\n" + studentList);
        int result = studentList.count;

        assertEquals(expected, result);
    }


    @Test
    public void testRemoveLast() {
        System.out.println("\nremoveLast");
        DoublyLinkedList instance = studentList;
        System.out.println("\nBefore\n" + studentList);
        int expected = studentList.count - 1;
        instance.removeLast();
        System.out.println("\nAfter\n" + studentList);
        int result = studentList.count;

        assertEquals(expected, result);
    }

 
    @Test
    public void testRemove() {
        System.out.println("\nremoveAny");
        DoublyLinkedList instance = studentList;
        System.out.println("\nBefore\n" + studentList);
        int expected = studentList.count - 1;
        instance.remove(student3);
        System.out.println("\nAfter\n" + studentList);
        int result = studentList.count;

        assertEquals(expected, result);
    }


    @Test
    public void testRemove_NotFound() {
        System.out.println("\nremoveAnyNotFound");
        DoublyLinkedList instance = studentList;
        System.out.println("\nBefore\n" + studentList);
        int expected = studentList.count;
        instance.remove(newStudent);
        System.out.println("\nAfter\n" + studentList);
        int result = studentList.count;

        assertEquals(expected, result);
    }

 
    @Test
    public void testContains() {
        System.out.println("\ncontains");
        Student find = student1;
        DoublyLinkedList instance = studentList;
        boolean expResult = true;
        boolean result = instance.contains(find);
        assertEquals(expResult, result);
    }

  
    @Test
    public void testContains_NotFound() {
        System.out.println("\ncontains");
        Student find = newStudent;
        DoublyLinkedList instance = studentList;
        boolean expResult = false;
        boolean result = instance.contains(find);
        assertEquals(expResult, result);
    }
}
