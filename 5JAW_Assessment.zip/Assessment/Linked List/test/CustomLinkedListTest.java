
import java.util.ArrayList;
import java.util.Arrays;
import linked.list.Course;
import linked.list.CustomLinkedList;
import linked.list.Enrollment;
import linked.list.Student;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gautam Anand
 */
public class CustomLinkedListTest {
     private static ArrayList<Student> students;
    private static ArrayList<Course> courses;
    private static ArrayList<Enrollment> enrollments;
    private static CustomLinkedList<Course> courseList;

    private static final Student student1 = new Student(100, "Gautam", "Gautam@mial.com","001128225", "07/11/2021","Software");
    private static final Student student2 = new Student(200, "Dale", "Dale@mial.com","001128226", "08/11/2021","Digital Media");
    private static final Student student3 = new Student(300, "Gustavo", "Gustavo@mial.com","001128227", "09/11/2021","IT");
    private static final Student student4 = new Student(400, "Ayaka", "Ayaka@mial.com","001128228", "10/11/2021","Digital Media");
    private static final Student student5 = new Student(500, "Kartikey", "Kartikey@mial.com", "001128229", "12/12/2021","IT");
    private static final Student student6 = new Student(600, "Kartik", "Kartik@mial.com","001128220", "17/11/2021","Health Care");
    
    

    private static final Course course1 = new Course(21, "Diploma of Software Development", 1299);
    private static final Course course2 = new Course(22, "Diploma of IT", 1199);
    private static final Course course3 = new Course(23, "Diploma of Health Care", 1219);
    private static final Course course4 = new Course(24, "Diploma of Digital Media", 2199);

    private static final    Enrollment enrollment1 = new Enrollment(course1,"11/11/21", "S2");
    private static final    Enrollment enrollment2 = new Enrollment(course4,"11/11/21", "S2");
    private static final    Enrollment enrollment3 = new Enrollment(course2,"12/12/21", "S2");
    private static final    Enrollment enrollment4 = new Enrollment(course1,"11/11/21", "S2");
    private static final    Enrollment enrollment5 = new Enrollment(course1,"11/11/21", "S2");


    public CustomLinkedListTest() {
    }


    @BeforeClass
    public static void setUpClass() {
        students = new ArrayList<>(Arrays.asList(student1, student2, student3, student4, student5, student6));
        courses = new ArrayList<>(Arrays.asList(course1, course2, course3, course4));
        enrollments = new ArrayList<>(Arrays.asList(enrollment1, enrollment2, enrollment3, enrollment4, enrollment5));
    }


    @AfterClass
    public static void tearDownClass() {
    }


    @Before
    public void setUp() {
        courseList = new CustomLinkedList<>();
        courseList.add(course1);
        courseList.add(course2);
        courseList.add(course3);
        courseList.add(course4);
    }


    @After
    public void tearDown() {
    }


    @Test
    public void testAddFirst() {
        System.out.println("addFirst");
        CustomLinkedList instance = courseList;
        Course add = new Course(01, "A course", 200);
        System.out.println("\nBefore\n" + courseList);
        int expected = courseList.count+1;
        
        instance.addFirst(add);
        System.out.println("\nAfter\n" + courseList);
        int result = courseList.count;
        assertEquals(expected, result);
        assertEquals(add, courseList.head.value);
    }


    @Test
    public void testAddLast() {
        System.out.println("AddLast");
        CustomLinkedList instance = courseList;
        Course add = new Course(01, "A course", 200);
        System.out.println("\nBefore\n" + courseList);
        int expected = courseList.count+1;
        
        instance.addLast(add);
        System.out.println("\nAfter\n" + courseList);
        int result = courseList.count;
        assertEquals(expected, result);
        assertEquals(add, courseList.tail.value);
    }


    @Test
    public void testRemoveFrist() {
        System.out.println("removeFirst");
        CustomLinkedList instance = courseList;
        System.out.println("\nBefore\n" + courseList);
        int expected = courseList.count -1;
        instance.removeFrist();
        System.out.println("\nAfter\n" + courseList);
        int result = courseList.count;
        
        assertEquals(expected, result);
    }

 
    @Test
    public void testRemoveLast() {
        System.out.println("removeLast");
        CustomLinkedList instance = courseList;
        System.out.println("\nBefore\n" + courseList);
        int expected = courseList.count -1;
        instance.removeLast();
        System.out.println("\nAfter\n" + courseList);
        int result = courseList.count;
        assertEquals(expected, result);
    }


    @Test
    public void testRemove() {
        System.out.println("\n\nremoveAny");
        Object remove = course3;
        CustomLinkedList instance = courseList;
        System.out.println("\nBefore\n" + courseList);
        
        int expected = courseList.count -1;
        boolean success = instance.remove(remove);
        
        System.out.println("\nAfter\n" + courseList);
        int result = courseList.count;
        assertEquals(success, true);
        assertEquals(expected, result);
    }
    

    @Test
    public void testRemove_NotFound() {
        System.out.println("\nremoveAnyNotFound");
        Object remove = new Course(01, "A course", 200);
        CustomLinkedList instance = courseList;
        System.out.println("\nBefore\n" + courseList);
        
        int expected = courseList.count;
        boolean success = instance.remove(remove);
        
        System.out.println("\nAfter\n" + courseList);
        int result = courseList.count;
        assertEquals(success, false);
        assertEquals(expected, result);
    }

 
    @Test
    public void testContains_Found() {
        System.out.println("contains");
        Course find = course1;
        CustomLinkedList instance = courseList;
        boolean expResult = true;
        boolean result = instance.contails(find);
        assertEquals(expResult, result);
    }
    
  
    @Test
    public void testContains_NotFound() {
        System.out.println("contains");
        Course find =  new Course(01, "A course", 200);
        CustomLinkedList instance = courseList;
        boolean expResult = false;
        boolean result = instance.contails(find);
        assertEquals(expResult, result);
    }
}
