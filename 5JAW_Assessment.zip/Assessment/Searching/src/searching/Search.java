/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package searching;

import java.util.ArrayList;

/**
 *
 * @author Gautam Anand
 */
public class Search {
    public static int binarySearch(ArrayList<Student> li, Student find) {
        int max = li.size();
        int min = 0;
        while (min <= max) {
            int mid = (min + max) / 2;
            int studentCompare = new StudentSortingComparator().compare(li.get(mid), find);

            if (li.get(mid).equals(find)) {
                return mid;
            } else if (studentCompare > 0) {
                max = mid - 1;
            } else {
                min = mid;
            }
        }
        return -1;
    }


    public static int binarySearch(ArrayList<Course> li, Course find) {
        int max = li.size() - 1;
        int min = 0;
        return binarySearch(li, find, min, max);
    }

    public static int binarySearch(ArrayList<Course> li, Course find, int min, int max) {
        if (min <= max) {
            int mid = (int) min + (max - min) / 2;
            int compare = new CourseSortingComparator().compare(li.get(mid), find);
            if (li.get(mid).equals(find)) {
                return mid;
            } else if (compare == 0 && min == max && !li.get(mid).equals(find)) {
                return -1;
            } else if (compare < 0) {
                return binarySearch(li, find, mid + 1, max);
            } else {
                return binarySearch(li, find, min, mid - 1);
            }
        }
        return -1;
    }


    public static int binarySearch(ArrayList<Enrollment> li, Enrollment find) {
        int max = li.size() - 1;
        int min = 0;
        return binarySearch(li, find, min, max);
    }

    public static int binarySearch(ArrayList<Enrollment> li, Enrollment find, int min, int max) {
        if (min <= max) {
            int mid = (int) min + (max - min) / 2;
            int compare = new EnrollmentSortingComparator().compare(li.get(mid), find);
            if (li.get(mid).equals(find)) {
                return mid;
            } else if (compare == 0 && min == max && !li.get(mid).equals(find)) {
                return -1;
            } else if (compare < 0) {
                return binarySearch(li, find, mid + 1, max);
            } else {
                return binarySearch(li, find, min, mid - 1);
            }
        }
        return -1;
    }


    public static int jumpSearch(ArrayList<Student> li, Student find) {
        int size = li.size();
        int jumpSize = (int) Math.floor(Math.sqrt(size));
        int jump = jumpSize;
        int prev = 0;
        int copareJump = new StudentSortingComparator().compare(li.get(Math.min(jump, size) - 1), find);
        while (copareJump < 0) {
            prev = jump;
            jump += jumpSize;
            if (prev >= size) {
                return -1;
            }
            copareJump = new StudentSortingComparator().compare(li.get(Math.min(jump, size) - 1), find);
        }
        int coparePrev = new StudentSortingComparator().compare(li.get(prev), find);
        while (coparePrev < 0) {
            prev++;
            coparePrev = new StudentSortingComparator().compare(li.get(prev), find);
            if (prev == Math.min(jump, size)) {
                break;
            }
        }
        if (li.get(prev).equals(find)) {
            return prev;
        }
        return -1;
    }


    public static int jumpSearch(ArrayList<Course> li, Course find) {
        int size = li.size();
        int jumpSize = (int) Math.floor(Math.sqrt(size));
        int jump = jumpSize;
        int prev = 0;
        int copareJump = new CourseSortingComparator().compare(li.get(Math.min(jump, size) - 1), find);
        while (copareJump < 0) {
            prev = jump;
            jump += jumpSize;
            if (prev >= size) {
                return -1;
            }
            copareJump = new CourseSortingComparator().compare(li.get(Math.min(jump, size) - 1), find);
        }
        int coparePrev = new CourseSortingComparator().compare(li.get(prev), find);
        while (coparePrev < 0) {
            prev++;
            coparePrev = new CourseSortingComparator().compare(li.get(prev), find);
            if (prev == Math.min(jump, size)) {
                break;
            }
        }
        if (li.get(prev).equals(find)) {
            return prev;
        }
        return -1;
    }


    public static int jumpSearch(ArrayList<Enrollment> li, Enrollment find) {
        int size = li.size();
        int jumpSize = (int) Math.floor(Math.sqrt(size));
        int jump = jumpSize;
        int prev = 0;
        int copareJump = new EnrollmentSortingComparator().compare(li.get(Math.min(jump, size) - 1), find);
        while (copareJump < 0) {
            prev = jump;
            jump += jumpSize;
            if (prev >= size) {
                return -1;
            }
            copareJump = new EnrollmentSortingComparator().compare(li.get(Math.min(jump, size) - 1), find);
        }
        int coparePrev = new EnrollmentSortingComparator().compare(li.get(prev), find);
        while (coparePrev < 0) {
            prev++;
            coparePrev = new EnrollmentSortingComparator().compare(li.get(prev), find);
            if (prev == Math.min(jump, size)) {
                break;
            }
        }
        if (li.get(prev).equals(find)) {
            return prev;
        }
        return -1;
    }
}
