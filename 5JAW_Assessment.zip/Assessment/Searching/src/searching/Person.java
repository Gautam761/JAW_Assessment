/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package searching;

/**
 *
 * @author Gautam Anand
 */
public class Person {
     public int id;
    public String name;
    public String email;
    public String telNum;
    public Address address;
    


    public Person(int id, String name, String email, String telNum) {
        this.name = name;
        this.email = email;
        this.telNum = telNum;
        this.id = id;
        this.address = null;
               
    }
    
    public void setAddress(int addressNum, String addressStreet, String addressSuburb, int addressPostcode, String addressState){
        this.address = new Address(addressNum, addressStreet, addressSuburb, addressPostcode, addressState);
    }

    @Override
    public String toString() {
        return "Person{" + "id=" + id + ", name=" + name + ", email=" + email + ", telNum=" + telNum + ", address=" + address + '}';
    }
}
