/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package searching;

import java.util.Comparator;

/**
 *
 * @author Gautam Anand
 */
public class CourseSortingComparator implements Comparator<Course> {
    @Override
    public int compare(Course c1, Course c2) {
        int idCompare =  c1.courseCode - c2.courseCode;
        if (idCompare == 0) {
            int nameCompare = c1.courseName.toLowerCase().compareTo(c2.courseName.toLowerCase());
            if (nameCompare == 0) {
                return  Double.compare(c1.courseCost, c2.courseCost);
            }
            return  nameCompare;
        }
        return idCompare;
    }
}
