
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import searching.Course;
import searching.CourseSortingComparator;
import searching.Enrollment;
import searching.EnrollmentSortingComparator;
import searching.Search;
import searching.Student;
import searching.StudentSortingComparator;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gautam Anand
 */
public class SearchTest {
    
    private static ArrayList<Student> students;
    private static ArrayList<Course> courses;
    private static ArrayList<Enrollment> enrollments;
    public SearchTest() {
    }

    @BeforeClass

    public static void setUpClass() {
        
        Student student1 = new Student(100, "Gautam", "Gautam@mial.com","001128225", "07/11/2021","Software");
        Student student2 = new Student(100, "Dale", "Dale@mial.com","001128225", "07/11/2021","Digital Media");
        Student student3 = new Student(100, "Gautam", "Dale@mial.com","001128225", "07/11/2021","Digital Media");
        Student student4 = new Student(100, "Gautam", "Gautam@mial.com","001128225", "07/11/2021","Digital Media");
        Student student5 = new Student(100, "Gautam", "Gautam@mial.com", "001128225", "02/12/2021","Digital Media");
        Student student6 = new Student(100, "Gautam", "Gautam@mial.com","001128225", "07/11/2021","Digital Media");
        students = new ArrayList<>(Arrays.asList(student4, student5, student3, student1, student2, student6));
        Collections.sort(students, new StudentSortingComparator());
        
        
        Course course1 = new Course(23, "Diploma of Software Development", 1299);
        Course course2 = new Course(22, "Diploma of Software Development", 1299);
        Course course3 = new Course(23, "Diploma of Information Technology", 1299);
        Course course4 = new Course(23, "Diploma of Software Development", 1199);
        Course course5 = new Course(4120, "Certificate 5 of Graphic Design", 3503);
        Course course6 = new Course(4140, "Diploma of Accounting", 5500);
        courses = new ArrayList<>(Arrays.asList(course5, course1, course3, course2, course4, course6));
        Collections.sort(courses, new CourseSortingComparator());
        
        Enrollment enrollment1 = new Enrollment(course1,"11/11/21", "S2");
        Enrollment enrollment2 = new Enrollment(course2,"11/11/21", "S2");
        Enrollment enrollment3 = new Enrollment(course1,"12/12/21", "S2");
        Enrollment enrollment4 = new Enrollment(course1,"11/11/21", "S2");
        enrollments = new ArrayList<>(Arrays.asList(enrollment4,enrollment1,enrollment3,enrollment2));
        Collections.sort(enrollments, new EnrollmentSortingComparator());
    }




    @Test
    public void testBinarySearch_ArrayList_Student() {
        System.out.println("binarySearch");
        Student find = students.get(3);
        int expResult = 3;
        int result = Search.binarySearch(students, find);
    }
    @Test
    public void testBinarySearch_ArrayList_Student_Last() {
        System.out.println("binarySearch");
        Student find = students.get(5);
        int expResult = 5;
        int result = Search.binarySearch(students, find);
    }
    @Test
    public void testBinarySearch_ArrayList_Student_First() {
        System.out.println("binarySearch");
        Student find = students.get(0);
        int expResult = 0;
        int result = Search.binarySearch(students, find);
       
    }
    

    @Test
    public void testBinarySearch_ArrayList_Course() {
        System.out.println("binarySearch");
        Course find = courses.get(3);
        int expResult = 3;
        int result = Search.binarySearch(courses, find);
    }
    @Test
    public void testBinarySearch_ArrayList_Course_First() {
        System.out.println("binarySearch");
        Course find = courses.get(0);
        int expResult = 0;
        int result = Search.binarySearch(courses, find);
    }
    @Test
    public void testBinarySearch_ArrayList_Course_Last() {
        System.out.println("binarySearch");
        Course find = courses.get(5);
        int expResult = 5;
        int result = Search.binarySearch(courses, find);
    }
    @Test
    public void testBinarySearch_ArrayList_Course_Not_Found() {
        System.out.println("binarySearch");
        Course find = new Course(4890, "A course", 0.0);
        int expResult = -1;
        int result = Search.binarySearch(courses, find);
    }

 
    @Test
    public void testBinarySearch_ArrayList_Enrollment() {
        System.out.println("binarySearch");
        Enrollment find = enrollments.get(1);
        int expResult = 1;
        int result = Search.binarySearch(enrollments, find);
    }
    @Test
    public void testBinarySearch_ArrayList_Enrollment_First() {
        System.out.println("binarySearch");
        Enrollment find = enrollments.get(0);
        int expResult = 0;
        int result = Search.binarySearch(enrollments, find);
    }
    @Test
    public void testBinarySearch_ArrayList_Enrollment_Last() {
        System.out.println("binarySearch");
        Enrollment find = enrollments.get(3);
        int expResult = 3;
        int result = Search.binarySearch(enrollments, find);
    }
    @Test
    public void testBinarySearch_ArrayList_Enrollment_Not_Found() {
        System.out.println("binarySearch");
        Enrollment find = new Enrollment(courses.get(3), "","");
        int expResult = -1;
        int result = Search.binarySearch(enrollments, find);
    }
    

    @Test
    public void testJumpSearch_ArrayList_Student() {
        System.out.println("jumpSearch");
        Student find = students.get(2);
        int expResult = 2;
        int result = Search.jumpSearch(students, find);
    }
    @Test
    public void testJumpSearch_ArrayList_Student_First() {
        System.out.println("jumpSearch");
        Student find = students.get(0);
        int expResult = 0;
        int result = Search.jumpSearch(students, find);
    }
    @Test
    public void testJumpSearch_ArrayList_Student_Last() {
        System.out.println("jumpSearch");
        Student find = students.get(students.size()-1);
        int expResult = students.size()-1;
        int result = Search.jumpSearch(students, find);
    }
    @Test
    public void testJumpSearch_ArrayList_Student_Not_Found() {
        System.out.println("jumpSearch");
        Student find = new Student(111, "" , "", "", "", "") ;
        int expResult = -1;
        int result = Search.jumpSearch(students, find);
    }
    
    

    @Test
    public void testJumpSearch_ArrayList_Course() {
        System.out.println("jumpSearch");
        Course find = courses.get(2);
        int expResult = 2;
        int result = Search.jumpSearch(courses, find);
    }
    @Test
    public void testJumpSearch_ArrayList_Course_First() {
        System.out.println("jumpSearch");
        Course find = courses.get(0);
        int expResult = 0;
        int result = Search.jumpSearch(courses, find);
    }
    @Test
    public void testJumpSearch_ArrayList_Course_Last() {
        System.out.println("jumpSearch");
        Course find = courses.get(courses.size()-1);
        int expResult = students.size()-1;
        int result = Search.jumpSearch(courses, find);
    }
    @Test
    public void testJumpSearch_ArrayList_Course_Not_Found() {
        System.out.println("jumpSearch");
        Course find = new Course(111, "" , 2.3) ;
        int expResult = -1;
        int result = Search.jumpSearch(courses, find);
    }

    
    @Test
    public void testJumpSearch_ArrayList_Enrollment() {
        System.out.println("jumpSearch");
        Enrollment find = enrollments.get(2);
        int expResult = 2;
        int result = Search.jumpSearch(enrollments, find);
    }
    @Test
    public void testJumpSearch_ArrayList_Enrollment_First() {
        System.out.println("jumpSearch");
        Enrollment find = enrollments.get(0);
        int expResult = 0;
        int result = Search.jumpSearch(enrollments, find);
    }
    @Test
    public void testJumpSearch_ArrayList_Enrollment_Last() {
        System.out.println("jumpSearch");
        Enrollment find = enrollments.get(enrollments.size()-1);
        int expResult = enrollments.size()-1;
        int result = Search.jumpSearch(enrollments, find);
    }
    @Test
    public void testJumpSearch_ArrayList_Enrollment_Not_Found() {
        System.out.println("jumpSearch");
        Enrollment find = new Enrollment(courses.get(1), "", "") ;
        int expResult = -1;
        int result = Search.jumpSearch(enrollments, find);
    }

}
