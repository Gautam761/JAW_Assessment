/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting;

import java.util.Comparator;

/**
 *
 * @author Gautam Anand
 */
public class StudentSortingComparator implements Comparator<Student> {
     @Override
    public int compare(Student s1, Student s2) { 
        int idCompare = s1.id - s2.id;
        return (idCompare == 0) ? (s1.name.toLowerCase().compareTo(s2.name.toLowerCase())) : idCompare;
    }
}
