/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting;

/**
 *
 * @author Gautam Anand
 */
public class Address {
    public int number;
    public String street;
    public String suburb;
    public int postcode;
    public String state;
    public Address(int number, String street, String suburb, int postcode, String state){
        this.number = number;
        this.street = street;
        this.suburb = suburb; 
        this.postcode = postcode;
        this.state = state; 
    }


    @Override
    public String toString() {
        return "Address{" + "id=" + ", number=" + number + ", street=" + street + ", suburb=" + suburb + ", postcode=" + postcode + ", state=" + state + '}';
    }
    
}
