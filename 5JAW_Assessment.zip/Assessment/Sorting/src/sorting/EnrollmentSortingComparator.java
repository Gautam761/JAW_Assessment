/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting;

import java.util.Comparator;

/**
 *
 * @author Gautam Anand
 */
public class EnrollmentSortingComparator implements Comparator<Enrollment> {
     @Override
    public int compare(Enrollment e1, Enrollment e2) {
        
        int courseCompare = new CourseSortingComparator().compare(e1.course, e2.course);
        if (courseCompare == 0) {
            return e1.dateEnrolled.compareTo(e2.dateEnrolled);
        }
        return courseCompare;
    }
}
