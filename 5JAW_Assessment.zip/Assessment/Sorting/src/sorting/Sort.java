/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 *
 * @author Gautam Anand
 */
public class Sort {
    public static void bubbleSortStudent(ArrayList<Student> li) {
        Student temp;
        for (int j = 0; j < li.size() - 1; j++) {
            for (int i = 0; i < li.size() - 1; i++) {
                if (li.get(i).name.compareTo(li.get(i + 1).name) > 0) {
                    temp = li.get(i + 1);
                    li.set(i + 1, li.get(i));
                    li.set(i, temp);
                }
            }
        }
    }


    public static void bubbleSortCourse(ArrayList<Course> li) {
        Course temp;
        for (int j = 0; j < li.size() - 1; j++) {
            for (int i = 0; i < li.size() - 1; i++) {
                if (li.get(i).courseCode - li.get(i + 1).courseCode > 0) {
                    temp = li.get(i + 1);
                    li.set(i + 1, li.get(i));
                    li.set(i, temp);
                }
            }
        }
    }

 
    public static void bubbleSortEnrollment(ArrayList<Enrollment> li) throws ParseException {
        Enrollment temp;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
        for (int j = 0; j < li.size() - 1; j++) {
            for (int i = 0; i < li.size() - 1; i++) {
                if (sdf.parse(li.get(i + 1).dateEnrolled).before(sdf.parse(li.get(i).dateEnrolled))) {
                    temp = li.get(i + 1);
                    li.set(i + 1, li.get(i));
                    li.set(i, temp);
                }
            }
        }
    }


    public static void quickSortCourse(ArrayList<Course> li) {
        int min = 0;
        int max = li.size() - 1;
        quickSortCourse(li, min, max);
    }
    
    

    private static void quickSortCourse(ArrayList<Course> li, int min, int max) {
        if (li == null || li.isEmpty()) {
            return;
        }
        if (min >= max) {
            return;
        }

        
        int mid = min + (max - min) / 2;
        Course pivot = li.get(mid);

        int i = min, j = max;
        while (li.get(i).courseCode < pivot.courseCode) {
            i++;
        }
        while (li.get(j).courseCode > pivot.courseCode) {
            j--;
        }
        if (i <= j) {
            swap(li, i, j);
            i++;
            j--;
        }

      
        if (min < j) {
            quickSortCourse(li, min, j);
        }
        if (max > i) {
            quickSortCourse(li, i, max);
        }

    }

 
    private static void swap(ArrayList<Course> li, int x, int y) {
        Course temp = li.get(x);
        li.set(x, li.get(y));
        li.set(y, temp);
    }

    
  
    public static void SelectionSortCourses(ArrayList<Course> li) {
        int len = li.size();

        for (int i = 0; i < len - 1; i++) {
            int min = i;
            
        
            for (int j = i + 1; j < len; j++) {
                if(li.get(j).courseCode < li.get(min).courseCode){
                    min = j;
                }
            }
            
           
            Course temp = li.get(min);
            li.set(min, li.get(i));
            li.set(i, temp);
            
        }
    }

}
