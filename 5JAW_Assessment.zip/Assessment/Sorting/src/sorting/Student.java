/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting;

import java.util.Objects;

/**
 *
 * @author Gautam Anand
 */
public class Student extends Person{
    public String program;
    public String dateRegistered;
    public Enrollment enrollent;
    public Student(int id, String name, String email, String telNum, String regDate, String program) {
        super(id, name, email, telNum);
        this.dateRegistered = regDate;
        this.program = program;
    }


    public void setEnrollment(Course course, String dateEnrolled, String semester) {
        this.enrollent = new Enrollment(course, dateEnrolled, semester);
    }


    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.id);
        return hash;
    }

    

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Student other = (Student) obj;
        
        return this.id == other.id;
    }


    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", telNum='" + telNum + '\'' +
                ", address=" + address +
                ", program='" + program + '\'' +
                ", dateRegistered='" + dateRegistered + '\'' +
                ", enrollent=" + enrollent +
                ", hashcode=" + this.hashCode() +
                '}';
    }

}
