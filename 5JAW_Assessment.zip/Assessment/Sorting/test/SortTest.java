
import java.util.ArrayList;
import java.util.Arrays;
import sorting.Course;
import sorting.Enrollment;
import sorting.Student;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Ignore;
import sorting.Sort;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gautam Anand
 */
public class SortTest {
     private static ArrayList<Student> studentsSorted;
    private static ArrayList<Course> coursesSorted;
    private static ArrayList<Enrollment> enrollmentsSorted;
    private static ArrayList<Student> studentsUnsorted;
    private static ArrayList<Course> coursesUnsorted;
    private static ArrayList<Enrollment> enrollmentsUnsorted;

    private static final Student s1 = new Student(102, "Gautam Anand", "Gautam@mail.com", "44112233", "27/02/20", "Business");
    private static final Student s2 = new Student(102, "Gautam Anand", "GAutam@mail.com", "44112233", "27/02/20", "Business");
    private static final Student s3 = new Student(104, "Jack Adams", "JSmith@mail.com", "0011223344", "12/06/20", "IT");
    private static final Student s4 = new Student(106, "Jack Smith", "JSmith@mail.com", "0011223344", "12/06/20", "IT");
    private static final Student s5 = new Student(103, "Joe Smith", "JSmith@mail.com", "0011223344", "02/01/20", "Art and Design");
    private static final Student s6 = new Student(101, "Mark Green", "MGreen@mail.com", "0011223344", "19/02/20", "IT");

    private static final Course c1 = new Course(4110, "Certificate 4 of Programming", 3000);
    private static final Course c2 = new Course(4111, "Dp. Software Development", 6203);
    private static final Course c3 = new Course(4112, "Diploma of Web Developent", 3345);
    private static final Course c4 = new Course(4120, "Certificate 5 of Graphic Design", 3503);
    private static final Course c5 = new Course(4140, "Diploma of Accounting", 5500);
    private static final Course c6 = new Course(4151, "Diploma of Software Development", 5203);

    private static final Enrollment e1 = new Enrollment(c1, "04/02/20", "S1");
    private static final Enrollment e2 = new Enrollment(c5, "30/02/20", "S1");
    private static final Enrollment e3 = new Enrollment(c2, "12/06/20", "S2");
    private static final Enrollment e4 = new Enrollment(c1, "17/06/20", "S1");
    private static final Enrollment e5 = new Enrollment(c1, "01/08/20", "S1");
    private static final Enrollment e6 = new Enrollment(c1, "18/06/21", "S1");

   
    public SortTest() {

    }

 
    @BeforeClass
    public static void setUpClass() {
        studentsSorted = new ArrayList<>(Arrays.asList(s1, s2, s3, s4, s5, s6));
        coursesSorted = new ArrayList<>(Arrays.asList(c1, c2, c3, c4, c5, c6));
        enrollmentsSorted = new ArrayList<>(Arrays.asList(e1, e2, e3, e4, e5, e6));

    }

 
    @AfterClass
    public static void tearDownClass() {
    }


    @Before
    public void setUp() {
        studentsUnsorted = new ArrayList<>(Arrays.asList(s4, s5, s3, s1, s2, s6));
        coursesUnsorted = new ArrayList<>(Arrays.asList(c5, c1, c3, c6, c2, c4));
        enrollmentsUnsorted = new ArrayList<>(Arrays.asList(e5, e2, e1, e4, e6, e3));
    }

    
    @After
    public void tearDown() {
    }


    @Test
    public void testBubbleSort() {
        System.out.println("\nbubbleSortStudent");
        ArrayList<Student> li = studentsUnsorted;
        for (int i = 0; i < li.size(); i++) {
            System.out.println("" + li.get(i));
        }
        Sort.bubbleSortStudent(li);
        System.out.println("bubbleSort");
        for (int i = 0; i < li.size(); i++) {
            System.out.println("" + li.get(i));
        }
        for (int i = 0; i < li.size(); i++) {
            assertEquals(studentsSorted.get(i), li.get(i));
        }
    }

 
    @Test
    public void testBubbleSortCourse() {
        System.out.println("\nbubbleSortCourse");
        ArrayList<Course> li = coursesUnsorted;
        for (int i = 0; i < li.size(); i++) {
            System.out.println("" + li.get(i));
        }
        Sort.bubbleSortCourse(li);
        System.out.println("bubbleSort");
        for (int i = 0; i < li.size(); i++) {
            System.out.println("" + li.get(i));
        }
        for (int i = 0; i < li.size(); i++) {
            assertEquals(coursesSorted.get(i), li.get(i));
        }
    }

 
    @Test
    public void testBubbleSortEnrollment() {
        System.out.println("\nbubbleSortEnrollment");
        ArrayList<Enrollment> li = enrollmentsUnsorted;
        for (int i = 0; i < li.size(); i++) {
            System.out.println("" + li.get(i));
        }
        try {
            Sort.bubbleSortEnrollment(li);
            System.out.println("bubbleSort");

        } catch (Exception a) {
            System.out.println("bubbleSort Fail");
        }
        for (int i = 0; i < li.size(); i++) {
            System.out.println("" + li.get(i));
        }
        for (int i = 0; i < li.size(); i++) {
            assertEquals(enrollmentsSorted.get(i), li.get(i));
        }
    }


    @Test
    public void testQuickSortCourse() {
        System.out.println("\ntestQuickSortCourse\nBefore:");
        ArrayList<Course> li = coursesUnsorted;
        for (int i = 0; i < li.size(); i++) {
            System.out.println("" + li.get(i));
        }
        Sort.quickSortCourse(li);
        System.out.println("After:");
        for (int i = 0; i < li.size(); i++) {
            System.out.println("" + li.get(i));
        }
        

        
        for (int i = 0; i < li.size(); i++) {
            assertEquals(coursesSorted.get(i), li.get(i));
        }
    }


    @Test
    public void testSelectionSortCourse() {
        System.out.println("\ntestSelectionSortCourse\nBefore:");
        ArrayList<Course> li = coursesUnsorted;
        for (int i = 0; i < li.size(); i++) {
            System.out.println("" + li.get(i));
        }
        Sort.SelectionSortCourses(li);
        System.out.println("After:");
        for (int i = 0; i < li.size(); i++) {
            System.out.println("" + li.get(i));
        }

        for (int i = 0; i < li.size(); i++) {
            
            assertEquals(coursesSorted.get(i), li.get(i));
        }
    }
}
