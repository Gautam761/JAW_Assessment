/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comparators;

import java.util.Comparator;

/**
 *
 * @author Gautam Anand
 */
public class CourseSortingComparator implements Comparator<Course> {
     @Override
    public int compare(Course course1, Course course2) {
        int idCompare = course1.courseCode - course2.courseCode;
        if (idCompare == 0) {
            int nameCompare = course1.courseName.toLowerCase().compareTo(course2.courseName.toLowerCase());
            if (nameCompare == 0) {
                return  Double.compare(course1.courseCost, course2.courseCost);
            }
            return  nameCompare;
        }
        return idCompare;
    }
}
