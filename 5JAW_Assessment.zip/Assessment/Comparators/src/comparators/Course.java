/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comparators;

import java.util.Objects;

/**
 *
 * @author Gautam Anand
 */
public class Course {
    public int courseCode;
    public String courseName;
    public double courseCost;

    public Course(int courseCode, String courseName, double courseCost) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.courseCost = courseCost;
    }
    

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Course course = (Course) o;
        return courseCode == course.courseCode;
    }

    @Override
    public int hashCode() {
        return Objects.hash(courseCode);
    }

    @Override
    public String toString() {
        return "Course{" +
                "courseCode=" + courseCode +
                ", courseName='" + courseName + '\'' +
                ", courseCost=" + courseCost +
                '}';
    }
}
