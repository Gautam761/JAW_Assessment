
import comparators.Student;
import comparators.StudentSortingComparator;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gautam Anand
 */
public class StudentSortingComparatorTest {
    public StudentSortingComparatorTest() {
    }
    
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }


    @Test
    public void testCompare() {
        System.out.println("Comparing");
        Student student1 = new Student(100, "Gautam", "Gautam@mial.com","001128225", "07/11/2021","Software");
        Student student2 = new Student(100, "Dale", "Dale@mial.com","001128225", "07/11/2021","Digital Media");
        StudentSortingComparator instance = new StudentSortingComparator();
        int expResult = 0;
        int result = instance.compare(student1, student2);
    }
}
