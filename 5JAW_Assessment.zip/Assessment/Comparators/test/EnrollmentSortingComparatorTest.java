
import comparators.Course;
import comparators.Enrollment;
import comparators.EnrollmentSortingComparator;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gautam Anand
 */
public class EnrollmentSortingComparatorTest {
     public EnrollmentSortingComparatorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }


    @Test
    public void testCompare() {
        System.out.println("Comparing");
        Course course1 = new Course(23, "Diploma of Software Development", 1299);
        Course course2 = new Course(22, "Diploma of Software Development", 1299);
        Enrollment enrollment1 = new Enrollment(course1,"11/11/21", "S2");
        Enrollment enrollment2 = new Enrollment(course2,"11/11/21", "S2");
        EnrollmentSortingComparator instance = new EnrollmentSortingComparator();
        int expResult = 0;
        int result = instance.compare(enrollment1, enrollment2);
       
    }
}
