
import comparators.Course;
import comparators.CourseSortingComparator;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Gautam Anand
 */
public class CourseSortingComparatorTest {
    public CourseSortingComparatorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }


    @Test
    public void testCompare() {
        System.out.println("Comparing");
        Course course1 = new Course(23, "Diploma of Software Development", 1299);
        Course course2 = new Course(22, "Diploma of Software Development", 1299);
        CourseSortingComparator instance = new CourseSortingComparator();
        int expResult = 0;
        int result = instance.compare(course1, course2);
    }
}
